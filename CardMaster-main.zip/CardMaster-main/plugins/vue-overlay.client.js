    import Vue from 'vue'
    import Loading from 'vue-loading-overlay'
    Vue.use(Loading)
