<template>
  <div>
    <div class="p-4">
        <div class="bg-white rounded-lg border shadow-lg w-full md:w-1/4 mx-auto p-4">
            <img src="/me.jpg" class="rounded-full overflow-hidden" alt="shakir abdo">
            <div class="text-center">
                <h3 class="text-xl font-bold mt-2">Shakir abdo</h3>
                <p class="text-gray-700 pb-1">Fullstack web Developer</p>
                <hr>
                <p class="text-gray-700 text-sm mt-5">Simple person with big dreams | Interested in JavaScript and UI/UX Design.</p>
                <p class="text-green-700 text-sm mt-2 text-left tracking-widest"><span class="font-bold text-black">Tech Stack:</span> NodeJs, NuxtJs, VueJS, MongoDB.</p>
                <div>
                    <h3 class="text-sm text-left tracking-widest"><span class="font-bold text-black">Contact:</span> <a href="https://t.me/shicolare1" target="_blank" class="hover:text-blue-500 hover:underline">Telegram</a> | <a href="https://github.com/shakir-abdo" class="hover:text-gray-700 hover:underline" target="_blank">Github</a></h3>
                </div>
            </div>
        </div>
    </div>
  </div>
</template>
